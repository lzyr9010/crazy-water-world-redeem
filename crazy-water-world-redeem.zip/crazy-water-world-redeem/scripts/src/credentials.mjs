import { createHash } from 'node:crypto';
const forbidden = ['testAccount', 'superToken'];
export function validateLogin(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('登录参数必须是 JSON 对象');
  for (const key of forbidden) if (input[key]) throw new Error('不支持测试账号或 superToken，请使用本人正式登录信息');
  let p = input.eworldParams ?? input;
  if (p.signToken != null || (p.timestamp == null && p.ts != null)) throw new Error('这是 SDK 原始返回，不是游戏登录参数：游戏 token/timestamp 映射不能直接照搬，请采集转换后的参数');
  const params = {};
  for (const key of ['openId','token','sign']) {
    if (typeof p[key] !== 'string' || !p[key].trim() || p[key].length > 4096) throw new Error('登录参数缺少或无效：'+key);
    params[key] = p[key];
  }
  if (typeof p.timestamp==='number'&&!Number.isSafeInteger(p.timestamp)) throw new Error('timestamp 数字精度已丢失，请使用原始十进制字符串');
  const timestamp = String(p.timestamp ?? '');
  if (!/^[1-9]\d{0,18}$/.test(timestamp) || BigInt(timestamp) > 9223372036854775807n) throw new Error('timestamp 必须是游戏使用的正整数int64，不是 signToken');
  params.timestamp = timestamp;
  const client = input.eworldClientInfo;
  if (!client || typeof client !== 'object' || Array.isArray(client)) throw new Error('本工具为避免猜测，要求同一次登录的 eworldClientInfo 快照（协议字段本身是optional）');
  const clientKeys=new Set(['appId','channelId','deviceModule','clientVersion','networkType','platform','did','sc','extc','biz','isAuth','birthday','originVersion']);
  for (const key of Object.keys(client)) if (!clientKeys.has(key)) throw new Error('存在尚未核实的clientInfo字段，请只保留协议允许的13项');
  for (const key of ['appId','channelId','platform']) if (typeof client[key]!=='string'||!client[key].trim()) throw new Error('缺少本人请求的 clientInfo.'+key+'，本工具保守拒绝猜值');
  for (const [key,value] of Object.entries(client)) if (key==='isAuth' ? typeof value!=='boolean' : typeof value!=='string'||value.length>4096) throw new Error('clientInfo字段无效：'+key);
  const login = {eworldParams:params,eworldClientInfo:{...client}};
  for (const key of ['language','systemLanguage']) if (input[key] != null) {
    if (typeof input[key] !== 'string' || input[key].length > 100) throw new Error('无效字段：'+key);
    login[key] = input[key];
  }
  if (input.worldId != null) {
    if (typeof input.worldId==='number'&&!Number.isSafeInteger(input.worldId)) throw new Error('worldId 精度已丢失，请使用原始十进制字符串');
    const world = String(input.worldId);
    if (!/^\d{1,19}$/.test(world)||BigInt(world)>9223372036854775807n) throw new Error('worldId 必须是原始请求中的非负int64');
    login.worldId = world;
  }
  if (input.loginRateType != null) {
    if (!Number.isInteger(input.loginRateType) || input.loginRateType < 0 || input.loginRateType > 2147483647) throw new Error('loginRateType 无效');
    login.loginRateType = input.loginRateType;
  }
  return {login,maskedAccount:maskAccount(params.openId),accountKey:accountKey(login),warnings:['时间戳单位与签名有效期未核实；保持签名配套原值，不转换时间戳，不刷新或伪造签名']};
}
export function maskAccount(id) {return '账号 …'+String(id).slice(-6);}
export function accountKey(login) { return createHash('sha256').update(JSON.stringify([login.eworldParams.openId,String(login.worldId??'')])).digest('hex'); }
export function normalizeCandidate(o) {
  // 只接受已转换的游戏字段，不从原始 SDK token 猜映射。
  if (!o || typeof o !== 'object' || Array.isArray(o) || forbidden.some(key=>o[key])) return null;
  const p = o.eworldParams ?? o;
  if (p.signToken != null || !['openId','token','sign'].every(k=>typeof p[k]==='string' && p[k].length>0) || !(/^[1-9]\d{0,18}$/.test(String(p.timestamp??''))) || (typeof p.timestamp==='number'&&!Number.isSafeInteger(p.timestamp))) return null;
  return {eworldParams:{openId:p.openId,token:p.token,timestamp:String(p.timestamp),sign:p.sign},...(o.eworldClientInfo?{eworldClientInfo:o.eworldClientInfo}:{}),...Object.fromEntries(['language','systemLanguage','worldId','loginRateType'].filter(k=>o[k]!=null).map(k=>[k,o[k]]))};
}
