export const SOURCE_URL = 'https://numb9870.github.io/crazy-water-world/%E5%85%91%E6%8D%A2%E7%A0%81/';
const FETCH_TIMEOUT_MS = 15_000;
const MAX_SOURCE_BYTES = 2 * 1024 * 1024;
const VOID_TAGS = new Set(['area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr']);
const RAW_TAGS = new Set(['script', 'style', 'template', 'noscript']);

// One decoding pass only: encoded markup remains plain text and is never parsed again.
function decodeEntities(text) {
  const named = { quot: '"', amp: '&', lt: '<', gt: '>', apos: "'" };
  return text.replace(/&(#x[0-9a-f]+|#\d+|quot|amp|lt|gt|apos);/gi, (entity, body) => {
    if (body[0] !== '#') return named[body.toLowerCase()];
    const hex = body[1]?.toLowerCase() === 'x';
    const number = Number.parseInt(body.slice(hex ? 2 : 1), hex ? 16 : 10);
    if (!Number.isSafeInteger(number) || number <= 0 || number > 0x10ffff || (number >= 0xd800 && number <= 0xdfff)) return '\uFFFD';
    return String.fromCodePoint(number);
  });
}

function validDate(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return null;
  const date = new Date(value + 'T00:00:00.000Z');
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value ? value : null;
}

function shanghaiToday() {
  const parts = new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Shanghai', year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(new Date());
  const values = Object.fromEntries(parts.map(({ type, value }) => [type, value]));
  return values.year + '-' + values.month + '-' + values.day;
}

function earlierDate(left, right) {
  const a = validDate(left);
  const b = validDate(right);
  return a && b ? (a < b ? a : b) : a || b || null;
}

/** Parse the fixed site's static card markup without a browser or script execution. */
export function parseSourceHtml(html) {
  if (typeof html !== 'string') throw new TypeError('来源 HTML 必须是字符串。');
  if (Buffer.byteLength(html, 'utf8') > MAX_SOURCE_BYTES) throw new Error('来源页面超过大小限制。');
  const cards = [];
  const stack = [];
  // Quoted attributes may contain >. Text entities are decoded only after tokenization.
  const tokens = /<!--[\s\S]*?-->|<![^>]*>|<\/?[a-zA-Z][^>"']*(?:"[^"]*"[^>"']*|'[^']*'[^>"']*)*>|[^<]+|</g;
  let match;
  const finish = (frame) => {
    if (!frame.card || !frame.role) return;
    if (frame.role === 'code' && frame.card.code === null) frame.card.code = decodeEntities(frame.text).trim();
    if (frame.role === 'date' && frame.card.publishedAt === null) {
      const date = decodeEntities(frame.text).match(/\b\d{4}-\d{2}-\d{2}\b/);
      frame.card.publishedAt = validDate(date?.[0]);
    }
  };
  while ((match = tokens.exec(html))) {
    const token = match[0];
    if (token.startsWith('<!--') || token.startsWith('<!')) continue;
    if (!token.startsWith('<') || token === '<') {
      const card = stack.at(-1)?.card;
      // A code or publication-date string is not an expiry label.
      if (card && !stack.some((frame) => frame.card === card && (frame.role === 'code' || frame.role === 'date'))) card.text += token;
      for (const frame of stack) if (frame.role) frame.text += token;
      continue;
    }
    const tag = token.match(/^<\/?([a-zA-Z][\w:-]*)/)?.[1]?.toLowerCase();
    if (!tag) continue;
    if (token.startsWith('</')) {
      const index = stack.findLastIndex((frame) => frame.tag === tag);
      if (index !== -1) while (stack.length > index) finish(stack.pop());
      continue;
    }
    if (RAW_TAGS.has(tag)) {
      const close = new RegExp('</' + tag + '\\s*>', 'gi');
      close.lastIndex = tokens.lastIndex;
      const end = close.exec(html);
      tokens.lastIndex = end ? close.lastIndex : html.length;
      continue;
    }
    const classMatch = token.match(/\sclass\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/i);
    const classes = new Set(decodeEntities(classMatch?.[1] ?? classMatch?.[2] ?? classMatch?.[3] ?? '').split(/\s+/));
    let card = stack.at(-1)?.card ?? null;
    if (classes.has('cdkey-card')) {
      card = { code: null, publishedAt: null, text: '' };
      cards.push(card);
    }
    const role = classes.has('cdkey-code') ? 'code' : classes.has('cdkey-date') ? 'date' : null;
    const frame = { tag, card, role, text: '' };
    if (VOID_TAGS.has(tag) || /\/\s*>$/.test(token)) finish(frame);
    else {
      if (stack.length >= 128) throw new Error('来源页面嵌套过深，已拒绝解析。');
      stack.push(frame);
    }
  }
  while (stack.length) finish(stack.pop());
  return cards.filter(({ code }) => typeof code === 'string' && code.length > 0).map((card) => {
    let expiresAt = null;
    for (const expiry of decodeEntities(card.text).matchAll(/过期\s*[：:]\s*(\d{4}-\d{2}-\d{2})/g)) expiresAt = earlierDate(expiresAt, expiry[1]);
    return { code: card.code, publishedAt: card.publishedAt, expiresAt, sourceUrl: SOURCE_URL };
  });
}

/** Fetch only the allowlisted URL, reject redirects, and cap total time/body bytes. */
export async function fetchSourceCodes() {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
  let reader;
  let body;
  try {
    const response = await fetch(SOURCE_URL, {
      signal: controller.signal,
      redirect: 'error',
      headers: { Accept: 'text/html', 'User-Agent': 'CrazyWaterWorldLocal/0.1 (static source reader)' },
    });
    body = response.body;
    if (!response.ok) throw new Error('来源服务请求失败（HTTP ' + response.status + '）。');
    if (!response.body) throw new Error('来源页面为空。');
    const declaredLength = response.headers.get('content-length');
    if (declaredLength && Number(declaredLength) > MAX_SOURCE_BYTES) throw new Error('来源页面超过大小限制。');
    reader = response.body.getReader();
    const chunks = [];
    let size = 0;
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > MAX_SOURCE_BYTES) throw new Error('来源页面超过大小限制。');
      chunks.push(value);
    }
    const records = parseSourceHtml(Buffer.concat(chunks, size).toString('utf8'));
    if (!records.length) throw new Error('来源页面未找到兑换码卡片，格式可能已变更。');
    return records;
  } catch (error) {
    if (controller.signal.aborted) throw new Error('读取来源超时，请稍后重试。');
    throw error;
  } finally {
    clearTimeout(timeout);
    if (reader) {
      try { await reader.cancel(); } catch { /* The body may already be aborted. */ }
      reader.releaseLock();
    } else if (body) {
      try { await body.cancel(); } catch { /* Rejecting headers must also close the body. */ }
    }
  }
}

/** Exact case-sensitive deduplication; only explicit expiry before Shanghai today is expired. */
export function prepareCodes(records, { today = shanghaiToday(), includeExpired = false } = {}) {
  if (!Array.isArray(records)) throw new TypeError('兑换码记录必须是数组。');
  if (!validDate(today)) throw new TypeError('today 必须是有效的 YYYY-MM-DD 日期。');
  const unique = new Map();
  const duplicates = [];
  for (const record of records) {
    if (!record || typeof record.code !== 'string') throw new TypeError('兑换码记录必须包含字符串 code。');
    const code = record.code.trim();
    if (!code) continue;
    const normalized = { ...record, code, publishedAt: validDate(record.publishedAt), expiresAt: validDate(record.expiresAt) };
    if (unique.has(code)) {
      duplicates.push(normalized);
      const kept = unique.get(code);
      kept.expiresAt = earlierDate(kept.expiresAt, normalized.expiresAt);
      kept.publishedAt = earlierDate(kept.publishedAt, normalized.publishedAt);
      if (!kept.sourceUrl && normalized.sourceUrl) kept.sourceUrl = normalized.sourceUrl;
    } else unique.set(code, normalized);
  }
  const all = [...unique.values()];
  const expired = all.filter((record) => record.expiresAt !== null && record.expiresAt < today);
  const codes = includeExpired ? all : all.filter((record) => record.expiresAt === null || record.expiresAt >= today);
  return { codes, duplicates, expired };
}
