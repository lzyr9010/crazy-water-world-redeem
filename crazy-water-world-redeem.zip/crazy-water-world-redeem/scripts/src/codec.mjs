const LIMIT=16*1024*1024;
export function nextSeq(seq) {if(!Number.isInteger(seq)||seq<1||seq>2147483647)throw new Error('服务器未提供有效 initSeqNo，拒绝猜测序号');return seq===2147483647?1:seq+1;}
export function encodeFrame(name,body,seq) {
  if(!/^[A-Za-z][A-Za-z0-9]{0,126}$/.test(name))throw new Error('消息名无效');
  if(!Number.isInteger(seq)||seq<0||seq>2147483647)throw new Error('序号无效');
  body=Buffer.from(body);const n=Buffer.byteLength(name);const out=Buffer.alloc(11+n+body.length);
  if(out.length>LIMIT)throw new Error('帧过大');
  out.writeInt32BE(out.length-4,0);out[4]=2;out.writeInt32BE(seq,5);out[9]=n;out.write(name,10,'ascii');out[10+n]=0;body.copy(out,11+n);return out;
}
export function decodeFrame(data) {
  const b=Buffer.from(data);if(b.length<11||b.length>LIMIT||b.readInt32BE(0)!==b.length-4||b[4]!==2)throw new Error('帧头或长度无效');
  const seq=b.readInt32BE(5),n=b[9];if(seq<0||n<1||n>127||11+n>b.length)throw new Error('帧序号/消息名长度无效');
  if(b.subarray(10,10+n).some(x=>x>127))throw new Error('消息名必须是ASCII');
  const name=b.toString('ascii',10,10+n);if(!/^[A-Za-z][A-Za-z0-9]*$/.test(name))throw new Error('消息名无效');
  const flag=b[10+n];let body;
  if(flag===0)body=b.subarray(11+n);else {
    if(b.length<15+n)throw new Error('压缩头截断');const size=b.readInt32BE(11+n);body=decodeLz4(b.subarray(15+n),size);
  }
  return {name,seq,body};
}
export function decodeLz4(input,size) {
  if(!Number.isInteger(size)||size<0||size>LIMIT)throw new Error('LZ4 解压长度无效');
  const src=Buffer.from(input),out=Buffer.alloc(size);let i=0,o=0;
  function length(n){if(n===15){let x;do{if(i>=src.length)throw new Error('LZ4 长度截断');x=src[i++];n+=x;if(n>LIMIT)throw new Error('LZ4 长度超限');}while(x===255);}return n;}
  while(i<src.length){const t=src[i++];const literals=length(t>>>4);if(i+literals>src.length||o+literals>size)throw new Error('LZ4 literal越界');src.copy(out,o,i,i+literals);i+=literals;o+=literals;if(i===src.length)break;
    if(i+2>src.length)throw new Error('LZ4 offset截断');const offset=src.readUInt16LE(i);i+=2;if(offset===0||offset>o)throw new Error('LZ4 offset无效');const match=length(t&15)+4;if(o+match>size)throw new Error('LZ4 match越界');for(let j=0;j<match;j++)out[o+j]=out[o+j-offset];o+=match;
  }
  if(o!==size)throw new Error('LZ4 解压长度不符');return out;
}
function varint(value){let v=BigInt(value);if(v<0n)v=BigInt.asUintN(64,v);if(v>18446744073709551615n)throw new Error('整数超出64位');const bytes=[];do{let b=Number(v&127n);v>>=7n;if(v)b|=128;bytes.push(b);}while(v);return Buffer.from(bytes);}
function readVarint(b,p){let v=0n;for(let k=0;k<10;k++){if(p.i>=b.length)throw new Error('protobuf整数截断');const x=b[p.i++];if(k===9 && x>1)throw new Error('protobuf整数溢出');v|=BigInt(x&127)<<BigInt(k*7);if(!(x&128))return v;}throw new Error('protobuf整数过长');}
export function encodeMessage(schema,obj,schemas){
  const parts=[];for(const f of schema){let value=obj[f.name];if(value==null){if(f.required)throw new Error('缺少必填字段：'+f.name);continue;}const values=f.repeated?(Array.isArray(value)?value:[]):[value];if(f.repeated&&!Array.isArray(value))throw new Error('字段必须是数组：'+f.name);
    for(const v of values){let body,wire;
      if(f.type==='string'){if(typeof v!=='string')throw new Error('字段必须是字符串：'+f.name);body=Buffer.from(v,'utf8');wire=2;}
      else if(f.type==='bytes'){body=Buffer.from(v);wire=2;}
      else if(schemas[f.type]){body=encodeMessage(schemas[f.type],v,schemas);wire=2;}
      else if(f.type==='double'){if(typeof v!=='number'||!Number.isFinite(v))throw new Error('double字段无效');body=Buffer.alloc(8);body.writeDoubleLE(v);wire=1;}
      else {if(!['int32','int64','bool'].includes(f.type))throw new Error('未知字段类型');let num=f.type==='bool'?(v?1n:0n):BigInt(v);if(f.type==='int32'&&(num< -2147483648n||num>2147483647n))throw new Error('int32越界');if(f.type==='int64'&&(num< -9223372036854775808n||num>9223372036854775807n))throw new Error('int64越界');body=varint(num);wire=0;}
      parts.push(varint(BigInt(f.id*8+wire)));if(wire===2)parts.push(varint(body.length));parts.push(body);
    }
  }return Buffer.concat(parts);
}
export function decodeMessage(schema,data,schemas,depth=0){
  if(depth>20)throw new Error('protobuf嵌套过深');const b=Buffer.from(data),p={i:0},obj={};const fields=new Map(schema.map(f=>[f.id,f]));
  while(p.i<b.length){const key=readVarint(b,p);const id=Number(key>>3n),wire=Number(key&7n);if(id<1)throw new Error('protobuf字段号无效');const f=fields.get(id);let value;
    if(wire===0){const n=readVarint(b,p);if(f){if(!['int32','int64','bool'].includes(f.type))throw new Error('protobuf wire类型不符');value=f.type==='int32'?Number(BigInt.asIntN(32,n)):f.type==='bool'?n!==0n:BigInt.asIntN(64,n).toString();}}
    else if(wire===2){const len=Number(readVarint(b,p));if(!Number.isSafeInteger(len)||len<0||p.i+len>b.length)throw new Error('protobuf长度越界');const chunk=b.subarray(p.i,p.i+len);p.i+=len;if(f){if(f.type==='string')value=new TextDecoder('utf-8',{fatal:true}).decode(chunk);else if(f.type==='bytes')value=chunk;else if(schemas[f.type])value=decodeMessage(schemas[f.type],chunk,schemas,depth+1);else throw new Error('protobuf wire类型不符');}}
    else if(wire===1||wire===5){const len=wire===1?8:4;if(p.i+len>b.length)throw new Error('protobuf截断');if(f){if(wire!==1||f.type!=='double')throw new Error('不支持的已知字段wire类型');value=b.readDoubleLE(p.i);if(!Number.isFinite(value))throw new Error('响应double非有限值');}p.i+=len;}
    else throw new Error('不支持protobuf group');
    if(f){if(f.repeated)(obj[f.name]??=[]).push(value);else obj[f.name]=value;}
  }
  for(const f of schema)if(f.required&&obj[f.name]==null)throw new Error('响应缺少必填字段：'+f.name);return obj;
}
