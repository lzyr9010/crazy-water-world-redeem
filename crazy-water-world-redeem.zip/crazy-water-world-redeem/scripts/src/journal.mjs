import { mkdir, readFile, open } from 'node:fs/promises';
import { dirname } from 'node:path';
export class Journal {
  constructor(path) { this.path=path; this.rows=[]; }
  async load() {
    let data=''; try {data=await readFile(this.path,'utf8');} catch(e) {if(e.code!=='ENOENT')throw e;}
    this.rows=[];
    const lines=data.split('\n');
    for(let i=0;i<lines.length;i++) {
      if(!lines[i].trim())continue;
      try {const row=JSON.parse(lines[i]);if(!row||!/^[a-f0-9]{64}$/.test(row.accountKey)||typeof row.code!=='string'||!['sending','success','rejected','unknown'].includes(row.status)||typeof row.at!=='string')throw new Error();this.rows.push(row);} catch {throw new Error('本地兑换记录损坏；停止真实兑换，请人工核对记录，勿删除后重试');}
    }
  }
  blocked(accountKey,code) { return this.rows.some(r=>r.accountKey===accountKey && r.code===code && ['sending','success','unknown'].includes(r.status)); }
  async record(accountKey,code,status,detail='') {
    const row={accountKey,code,status,detail,at:new Date().toISOString()};
    await mkdir(dirname(this.path),{recursive:true});
    const f=await open(this.path,'a',0o600);
    try {await f.writeFile(JSON.stringify(row)+'\n');await f.sync();} finally {await f.close();}
    this.rows.push(row);
  }
}
