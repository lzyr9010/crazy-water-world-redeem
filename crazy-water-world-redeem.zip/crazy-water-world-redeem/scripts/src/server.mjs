import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { dirname,join,resolve } from 'node:path';
import { randomUUID,randomBytes,createHash } from 'node:crypto';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { validateLogin,normalizeCandidate,maskAccount } from './credentials.mjs';
import { Journal } from './journal.mjs';
import { BatchRunner } from './runner.mjs';
import { SOURCE_URL,fetchSourceCodes,prepareCodes } from './source.mjs';
import { decodeFrame,decodeMessage } from './codec.mjs';
import { schemas } from './schema.mjs';
const ROOT=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const execute=promisify(execFile),VERSION='0.1.0';
const staticFiles=new Map([['/', ['index.html','text/html; charset=utf-8']],['/app.mjs',['app.mjs','text/javascript; charset=utf-8']],['/style.css',['style.css','text/css; charset=utf-8']]]);
function json(res,status,value){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8'});res.end(JSON.stringify(value));}
async function bodyJson(req){let size=0;const chunks=[];for await(const chunk of req){size+=chunk.length;if(size>640*1024)throw new Error('请求超过640KiB限制');chunks.push(chunk);}const value=JSON.parse(Buffer.concat(chunks).toString('utf8'));if(!value||typeof value!=='object'||Array.isArray(value))throw new Error('请求必须是JSON对象');return value;}
async function nativeHelper(args){
  if(process.platform!=='win32')throw new Error('自动采集仅支持Windows；其他系统请手动输入本人完整登录JSON');
  try{const result=await execute(join(process.env.SystemRoot??'C:/Windows','System32','WindowsPowerShell','v1.0','powershell.exe'),['-NoProfile','-ExecutionPolicy','RemoteSigned','-File',join(ROOT,'tools','CaptureLogin.ps1'),...args],{encoding:'utf8',timeout:180000,maxBuffer:4*1024*1024,windowsHide:true});return JSON.parse(result.stdout.replace(/^\uFEFF/,''));}
  catch{throw new Error('本地采集脚本未成功运行；请检查目标进程、同等权限与脚本策略，不关闭安全防护；错误原文不回显，以免泄露凭据');}
}
const digest=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
export async function createApp({journalPath=join(ROOT,'data','redeem-history.jsonl'),journal=new Journal(journalPath),helper=nativeHelper,sourceFetcher=fetchSourceCodes,sessionFactory}={}){
  await journal.load();const runner=new BatchRunner(journal,sessionFactory?{sessionFactory}:{});
  const csrf=randomBytes(32).toString('hex');let credential=null,candidateStore=new Map(),sourceRecords=[],preview=null,mutating=false;
  const currentStatus=()=>({...runner.state,maskedAccount:credential?.maskedAccount??runner.state.maskedAccount??'',credentialSelected:!!credential});
  const idle=()=>{if(runner.busy()||mutating)throw new Error('已有任务或凭据操作正在进行；请等待结束');};
  function select(login){credential=validateLogin(login);preview=null;return {maskedAccount:credential.maskedAccount,warnings:credential.warnings};}
  function build(p){
    if(!['simulation','live'].includes(p.mode))throw new Error('请选择simulation或live模式');
    if(p.mode==='live'&&!credential)throw new Error('真实兑换需要本人同一次登录的完整参数');
    if(typeof p.codes!=='string'||Buffer.byteLength(p.codes)>512*1024)throw new Error('codes须为512KiB内的每行一码文本');
    const intervalMs=p.intervalMs??3000;if(!Number.isInteger(intervalMs)||intervalMs<3000||intervalMs>60000)throw new Error('请求间隔须为3000～60000毫秒整数');
    if(p.includeExpired!=null&&typeof p.includeExpired!=='boolean')throw new Error('includeExpired须为boolean');
    const imported=prepareCodes(sourceRecords,{includeExpired:true}).codes,metadata=new Map(imported.map(r=>[r.code,r]));
    const lines=p.codes.replace(/^\uFEFF/,'').split(/\r?\n/).map(s=>s.trim()).filter(Boolean);
    if(lines.length>2000)throw new Error('单批最多2000行、500个去重码，请拆分');
    for(const code of lines)if(Buffer.byteLength(code)>256||/[\x00-\x1f\x7f]/.test(code))throw new Error('兑换码含控制字符或超过256字节，已拒绝');
    const prepared=prepareCodes(lines.map(code=>({...metadata.get(code),code})),{includeExpired:p.includeExpired===true});
    if(prepared.codes.length>500)throw new Error('单批最多500个去重码');
    const blocked=[],codes=[];
    for(const r of prepared.codes){if(p.mode==='live'&&journal.blocked(credential.accountKey,r.code))blocked.push({...r,status:'blocked'});else codes.push({...r,status:'pending',detail:'尚未发送'});}
    const fingerprint=digest({mode:p.mode,codes:codes.map(r=>r.code),intervalMs,includeExpired:p.includeExpired===true,login:p.mode==='live'?credential.login:null});
    return {...prepared,codes,blocked,mode:p.mode,intervalMs,maskedAccount:p.mode==='live'?credential.maskedAccount:'',fingerprint};
  }
  const server=http.createServer(async(req,res)=>{
    res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('X-Frame-Options','DENY');res.setHeader('Referrer-Policy','no-referrer');
    res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'");
    const port=server.address()?.port,expected='127.0.0.1:'+port,origin='http://'+expected;
    if(req.headers.host!==expected|| (req.headers.origin&&req.headers.origin!==origin)||req.headers['sec-fetch-site']==='cross-site'){json(res,403,{error:'拒绝非本机同源访问'});return;}
    const path=new URL(req.url,origin).pathname;
    try{
      if(req.method==='GET'&&staticFiles.has(path)){const [file,type]=staticFiles.get(path);res.writeHead(200,{'Content-Type':type});res.end(await readFile(join(ROOT,'public',file)));return;}
      if(req.method==='GET'&&path==='/api/bootstrap'){json(res,200,{csrf,version:VERSION,sourceUrl:SOURCE_URL});return;}
      if(req.method==='GET'&&path==='/api/status'){json(res,200,currentStatus());return;}
      if(req.method==='GET'&&path==='/api/processes'){json(res,200,await helper(['-List']));return;}
      if(req.method==='GET'&&path==='/api/codes'){const records=await sourceFetcher();sourceRecords=records;preview=null;json(res,200,{records,sourceUrl:SOURCE_URL});return;}
      if(req.method!=='POST'){json(res,404,{error:'接口不存在'});return;}
      if(req.headers['x-local-token']!==csrf||!String(req.headers['content-type']??'').startsWith('application/json')){json(res,403,{error:'缺少同源安全令牌或JSON类型'});return;}
      const p=await bodyJson(req);
      if(path==='/api/stop'){runner.stop();json(res,200,currentStatus());return;}
      idle();
      if(path==='/api/credentials'){json(res,200,select(p.login));return;}
      if(path==='/api/clear-credentials'){credential=null;candidateStore.clear();preview=null;runner.state={state:'idle',mode:'simulation',rows:[],error:null};json(res,200,{cleared:true});return;}
      if(path==='/api/capture'){
        if(p.consent!==true)throw new Error('请明确同意只读采集本机微信小程序内存');
        if(p.auto!==true&&(!Number.isSafeInteger(p.pid)||p.pid<=0))throw new Error('请选择本人小游戏PID，或使用自动扫描');
        mutating=true;candidateStore.clear();preview=null;
        try{
          const args=p.auto===true?['-Auto']:['-TargetPid',String(p.pid)];
          const result=await helper(args);
          const candidates=[],capturedAt=new Date().toISOString(),seen=new Set(),diagnostics=[];
          let frameCount=0,parseFail=0;
          for(const proc of (result.scanned??[])){
            if(!proc||typeof proc.pid!=='number')continue;
            diagnostics.push({pid:proc.pid,memoryMB:proc.memoryMB??null,scannedMB:proc.scannedMB??null,frames:Array.isArray(proc.frames)?proc.frames.length:0});
            for(const encoded of (proc.frames??[]).slice(0,32)){
              frameCount++;
              let raw=null;
              try{
                const frame=decodeFrame(Buffer.from(String(encoded),'base64'));
                if(frame.name!=='LoginRequest')continue;
                raw=decodeMessage(schemas.LoginRequest,frame.body,schemas);
              }catch{parseFail++;continue;}
              const login=normalizeCandidate(raw);if(!login)continue;
              const key=digest(login);if(seen.has(key))continue;seen.add(key);
              const id=randomUUID();let checked=null,warnings=[];
              try{checked=validateLogin(login);}catch(e){warnings.push(e.message);}
              candidateStore.set(id,{login,checked,expiresAt:Date.now()+5*60*1000});
              candidates.push({id,maskedAccount:maskAccount(login.eworldParams.openId),capturedAt,hasClientInfo:!!checked,warnings,sourcePid:proc.pid});
            }
          }
          const warnings=[...(result.warnings??[])];
          if(!frameCount)warnings.push('未在微信小程序进程中找到登录帧。请确认小游戏已打开并进入过游戏主界面后重试。');
          else if(!candidates.length)warnings.push('找到登录帧但参数不完整（可能缺少客户端信息），无法用于真实兑换。');
          if(parseFail)warnings.push('有 '+parseFail+' 个候选帧解码失败，已跳过。');
          json(res,200,{candidates,diagnostics,warnings});return;
        }finally{mutating=false;}
      }
      if(path==='/api/select-credential'){const candidate=candidateStore.get(p.id);if(!candidate||candidate.expiresAt<Date.now())throw new Error('候选不存在或已过期，请重新只读采集');if(!candidate.checked)throw new Error('候选缺少完整客户端信息，不猜值，不能选用');const result=select(candidate.login);candidateStore.clear();json(res,200,result);return;}
      if(path==='/api/preview'){const plan=build(p);const token=randomUUID();preview={token,fingerprint:plan.fingerprint,expiresAt:Date.now()+5*60*1000};const {fingerprint,...visible}=plan;json(res,200,{...visible,previewToken:token});return;}
      if(path==='/api/start'){
        if(p.confirmation!==true)throw new Error('须先核对最终清单并明确确认；真实操作可能踢下线并消耗资格');
        const plan=build(p);
        if(!preview||p.previewToken!==preview.token||preview.expiresAt<Date.now()||preview.fingerprint!==plan.fingerprint)throw new Error('预览已过期或账号/清单/模式/间隔发生变化，请重新预览确认');
        if(!plan.codes.length)throw new Error('没有可运行兑换码，未连接游戏');
        preview=null;const runId=runner.start({mode:plan.mode,rows:plan.codes,intervalMs:plan.intervalMs,credential:plan.mode==='live'?credential:null});json(res,202,{runId,...currentStatus()});return;
      }
      json(res,404,{error:'接口不存在'});
    }catch(e){if(!res.headersSent)json(res,400,{error:e instanceof SyntaxError?'JSON解析失败':e.code?'本地文件操作失败；停止并检查权限/记录，不删除记录后重试':e.message});else res.end();}
  });
  server.on('clientError',(_error,socket)=>{socket.end('HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n');});
  server.headersTimeout=10000;server.requestTimeout=45000;
  return {server,runner,journal,async close(){runner.stop();await runner.task;credential=null;candidateStore.clear();if(server.listening)await new Promise((r,e)=>server.close(error=>error?e(error):r()));}};
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  try{
    const app=await createApp();await new Promise((r,e)=>{app.server.once('error',e);app.server.listen(8765,'127.0.0.1',r);});
    console.log('疯狂水世界批量兑换（实验版） http://127.0.0.1:8765');console.log('默认离线模拟；真实请求必须在界面预览并确认。凭据不写入文件。Ctrl+C停止服务。');
    let shuttingDown=false;const quit=async()=>{if(shuttingDown)return;shuttingDown=true;console.log('正在停止，不再提交新码；已提交的请求无法撤回，等待当前请求收尾。');await app.close();};process.on('SIGINT',quit);process.on('SIGTERM',quit);
  }catch(e){console.error(e.code==='EADDRINUSE'?'本机8765端口已占用，请勿启动多个实例。':'启动失败：本地记录或运行环境异常；检查后再试，勿删除历史以绕过防重。');process.exitCode=1;}
}
