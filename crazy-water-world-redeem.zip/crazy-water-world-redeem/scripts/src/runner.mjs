import { randomUUID } from 'node:crypto';
import { setTimeout as sleep } from 'node:timers/promises';
import { GameSession } from './session.mjs';
export class BatchRunner {
  constructor(journal,{sessionFactory=login=>new GameSession(login)}={}){this.journal=journal;this.sessionFactory=sessionFactory;this.state={state:'idle',mode:'simulation',rows:[],error:null};this.task=null;}
  busy(){return ['running','stopping'].includes(this.state.state);}
  start({mode,rows,intervalMs,credential}){
    if(this.busy())throw new Error('已有兑换任务，只允许串行运行');
    if(!['live','simulation'].includes(mode))throw new Error('模式无效');
    const runId=randomUUID();this.stopRequested=false;
    this.state={state:'running',mode,runId,maskedAccount:credential?.maskedAccount??'离线模拟（非真实账号）',rows:rows.map(r=>({...r})),error:null};
    this.task=this.execute({mode,intervalMs,credential});return runId;
  }
  stop(){if(this.busy()){this.stopRequested=true;this.state.state='stopping';}return this.state;}
  async execute({mode,intervalMs,credential}){
    let session=null;
    try{
      if(mode==='live'&&!this.stopRequested){session=this.sessionFactory(credential.login);await session.open();}
      let sent=0;
      for(const row of this.state.rows){
        if(row.status!=='pending')continue;
        if(this.stopRequested)break;
        // 模拟只短暂让出事件循环；限速用于真实请求，不让114条离线检查等待数分钟。
        if(sent>0){for(let left=mode==='simulation'?10:intervalMs;left>0&&!this.stopRequested;left-=Math.min(left,100))await sleep(Math.min(left,100));if(this.stopRequested)break;}
        if(mode==='simulation'){
          row.status='simulated';row.detail='仅验证队列和字段，不连接游戏、不领取奖励';sent++;continue;
        }
        // 发送前必须durable记录：重启也不重发sending/unknown，换账号使用不同hash。
        await this.journal.record(credential.accountKey,row.code,'sending');
        if(this.stopRequested){row.status='not_sent';row.detail='在发送前停止，记录保守锁定；需人工核对';break;}
        row.status='sending';row.detail='已提交，等待服务器回应；停止不能撤回';sent++;
        try{
          const outcome=await session.redeem(row.code);row.status=outcome.status;row.detail=outcome.detail;
          await this.journal.record(credential.accountKey,row.code,row.status,row.detail);
          if(outcome.stop){this.stopRequested=true;this.state.error=outcome.detail;break;}
        }catch(e){
          row.status='unknown';row.detail=e.message;
          await this.journal.record(credential.accountKey,row.code,'unknown',row.detail);
          this.state.error='已发请求结果未知，停止；先在游戏核对，不重试';this.stopRequested=true;break;
        }
      }
      for(const row of this.state.rows)if(row.status==='pending'){row.status='not_sent';row.detail='任务停止，未发送';}
      this.state.state=this.stopRequested?'stopped':'completed';
    }catch(e){
      this.state.state='error';this.state.error=e.message;
      for(const row of this.state.rows)if(row.status==='pending'){row.status='not_sent';row.detail='登录/本地记录失败，未发送';}else if(row.status==='sending'){row.status='unknown';row.detail='结果记录失败，人工核对；发送前记录仍会阻止重发';}
    }finally{session?.close();credential=null;}
  }
}
