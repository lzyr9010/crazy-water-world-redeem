// 来源：历史 mem_gift.bin 的静态 protobuf 定义，未将游戏代码作为可执行依赖。
const f=(id,name,type,required=false,repeated=false)=>({id,name,type,required,repeated});
export const schemas={
  EworldLoginParams:[f(1,'openId','string',true),f(2,'token','string',true),f(3,'timestamp','int64',true),f(4,'sign','string',true)],
  EworldClientInfo:['appId','channelId','deviceModule','clientVersion','networkType','platform','did','sc','extc','biz','isAuth','birthday','originVersion'].map((name,i)=>f(i+1,name,name==='isAuth'?'bool':'string')),
  LoginRequest:[f(4,'language','string'),f(6,'eworldParams','EworldLoginParams'),f(7,'eworldClientInfo','EworldClientInfo'),f(8,'worldId','int64'),f(9,'systemLanguage','string'),f(10,'loginRateType','int32')],
  LoginResponse:[f(1,'result','int32'),f(2,'playerInfo','PlayerInfo'),f(3,'errorMessage','string'),f(4,'initSeqNo','int32')],
  GotGiftCodeRequest:[f(1,'giftCode','string')],
  PromptResponse:[f(1,'style','int32',true),f(2,'prompt','int32',true),f(3,'args','string',false,true)],
  Ack:[f(1,'seqNo','int32',true)],Nack:[f(1,'seqNo','int32',true)],
  PingRequest:[f(1,'clientTimestamp','int64',true)],PingResponse:[f(1,'clientTimestamp','int64',true),f(2,'serverTimestamp','int64',true)],
  // 只列出工具消费的PlayerInfo字段，其余字段按wire安全跳过，不构造新角色。
  PlayerInfo:[f(1,'playerId','int64'),f(2,'nickname','string'),f(11,'newRole','bool'),f(12,'worldId','int64')],
  GotRewardResponse:[f(1,'reward','DisplayAssetPackage'),f(2,'hero','DisplayHeroAsset',false,true),f(3,'antique','DisplayAntiqueAsset',false,true),f(4,'equipIds','string',false,true),f(5,'badge','DisplayBadgeAsset',false,true),f(6,'tickets','string',false,true),f(7,'supply','DispSupply',false,true)],
  DisplayAssetPackage:[f(1,'asset','DisplayAsset',false,true)],
  DisplayAsset:[f(1,'type','int32',true),f(2,'id','string',true),f(3,'num','int64',true)],
  DisplayHeroAsset:[f(1,'heroId','string'),f(2,'frag','bool')],
  DisplayAntiqueAsset:[f(1,'antiqueId','string'),f(2,'frag','bool')],
  DisplayBadgeAsset:[f(1,'badgeId','string',true),f(2,'star','int32',true),f(3,'uid','int64'),f(4,'attr','EnhanceAttrValue')],
  DispSupply:[f(1,'uid','int64',true),f(2,'supId','string',true),f(3,'shapeId','int32',true),f(4,'attr','EnhanceAttrValue')],
  EnhanceAttrValue:[f(1,'attr','int32'),f(2,'value','double'),f(3,'rating','int32')],
};
export const PROMPTS={63:'礼包码已过期',64:'礼包码无效',65:'礼包码已使用',66:'该批次已领取',67:'礼包码已被其他玩家使用',99:'礼包码已过期或尚未生效',100:'礼包码使用次数超限',101:'请求过多，已停止，请稍后人工核对'};
export const LOGIN_RESULTS={0:'登录成功',1:'服务器维护',2:'登录参数错误',3:'账号被限制',4:'系统繁忙',5:'不允许新建角色',6:'渠道错误',7:'账号撤销',100:'未知登录错误',101:'服务器未开放'};
