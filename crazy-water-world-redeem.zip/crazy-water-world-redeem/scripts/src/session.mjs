import { encodeFrame,decodeFrame,encodeMessage,decodeMessage,nextSeq } from './codec.mjs';
import { schemas,PROMPTS,LOGIN_RESULTS } from './schema.mjs';
export const GAME_URL='wss://dhyaoj-gate.khlgamen.com/ws';
const MAX=2147483647,HALF=(MAX-1)/2;
const isOld=(a,b)=>{const lower=b-HALF;return lower>0?a>=lower&&a<=b:(a>=1&&a<=b)||a>=MAX+lower;};
export function rewardCount(r) {
  let n=(r.reward?.asset??[]).filter(x=>[0,1].includes(x.type)&&x.id&&BigInt(x.num)>0n).length;
  for(const [field,key] of [['hero','heroId'],['antique','antiqueId'],['badge','badgeId'],['supply','supId']])n+=(r[field]??[]).filter(x=>typeof x[key]==='string'&&x[key].length>0).length;
  n+=(r.equipIds??[]).filter(Boolean).length+(r.tickets??[]).filter(Boolean).length;return n;
}
export class GameSession {
  constructor(login,{WebSocketImpl=globalThis.WebSocket,responseTimeoutMs=20000,heartbeatMs=1000,pongTimeoutMs=1000}={}) {
    this.login=login;this.WebSocketImpl=WebSocketImpl;this.responseTimeoutMs=responseTimeoutMs;this.heartbeatMs=heartbeatMs;this.pongTimeoutMs=pongTimeoutMs;
    this.closed=false;this.authorized=false;this.pending=null;this.recvSeq=null;this.sendSeq=Math.floor(Math.random()*1000)+1;this.pingTimestamp=null;this.ackTimer=null;this.tick=null;
  }
  pack(name,obj,seq=0){return encodeFrame(name,encodeMessage(schemas[name],obj,schemas),seq);}
  parse(frame){if(!schemas[frame.name])throw new Error('未核实的响应类型：'+frame.name);return decodeMessage(schemas[frame.name],frame.body,schemas);}
  open(){
    if(this.socket)throw new Error('会话已启动');
    return new Promise((resolve,reject)=>{
      this.authResolve=resolve;this.authReject=reject;this.authTimer=setTimeout(()=>this.fail('登录或连接超时；不会自动重连'),this.responseTimeoutMs);
      try {const socket=this.socket=new this.WebSocketImpl(GAME_URL);socket.binaryType='arraybuffer';
        socket.addEventListener('open',()=>{try{this.sendSeq=nextSeq(this.sendSeq);socket.send(this.pack('LoginRequest',this.login,this.sendSeq));}catch{this.fail('登录参数编码失败');}});
        socket.addEventListener('message',event=>{try{if(typeof event.data==='string')throw new Error('拒绝非二进制响应');this.onFrame(decodeFrame(event.data));}catch(e){this.fail(/^(未核实|登录失败|服务器提示新角色|服务器返回区服)/.test(e.message)?e.message:'响应解码或校验失败；停止，勿自动重试');}});
        socket.addEventListener('close',()=>this.fail('连接已断开；已发请求结果需人工核对'));
        socket.addEventListener('error',()=>this.fail('游戏服务器连接失败；未关闭TLS校验'));
      }catch{this.fail('无法建立 WebSocket 连接');}
    });
  }
  onFrame(frame){
    if(this.closed)return;
    if(!this.authorized){
      if(frame.name!=='LoginResponse')throw new Error('未核实的登录响应类型：'+frame.name);
      const r=this.parse(frame);
      if(r.result!==0)throw new Error('登录失败：'+(LOGIN_RESULTS[r.result]??'未知/缺失结果'));
      nextSeq(r.initSeqNo); // 仅检验，普通send时才真正递增。
      if(r.playerInfo?.newRole===true)throw new Error('服务器提示新角色，停止兑换；请核对原区服参数');
      // worldId=0 是原客户端 loginSDK 单参调用的用法，表示由服务器分配区服；只有显式指定了非 0 区服才比对。
      const wantWorld=this.login.worldId==null?'':String(this.login.worldId);
      if(wantWorld!==''&&wantWorld!=='0'&&r.playerInfo?.worldId!=null&&wantWorld!==String(r.playerInfo.worldId))throw new Error('服务器返回区服与登录参数不同，停止兑换');
      this.sendSeq=r.initSeqNo;this.authorized=true;clearTimeout(this.authTimer);const resolve=this.authResolve;this.authResolve=null;this.authReject=null;
      this.ping();this.tick=setInterval(()=>{if(this.closed)return;if(this.pingTimestamp!=null){if(Date.now()-this.pingTimestamp>this.pongTimeoutMs)this.fail('心跳超时；不会自动重连或重发');}else this.ping();},this.heartbeatMs);resolve();return;
    }
    if(frame.name==='PingResponse'){const pong=this.parse(frame);if(pong.clientTimestamp===String(this.pingTimestamp))this.pingTimestamp=null;return;}
    if(['ResendFailed','SCChannelExpired'].includes(frame.name)){this.fail('游戏会话已失效：'+frame.name);return;}
    if(!this.acceptSeq(frame.seq))return;
    if(frame.name.startsWith('SC'))return; // 下行推送只维护顺序，不复刻其他玩法。
    if(!frame.name.endsWith('Response'))return;
    if(!this.pending){this.fail('收到无对应请求的响应，避免串单已停止');return;}
    const p=this.pending;this.pending=null;clearTimeout(p.timer);
    try{p.resolve({name:frame.name,body:this.parse(frame)});}catch(e){p.reject(e);this.fail('未知或无效业务响应');}
  }
  acceptSeq(seq){
    if(seq===0)return true;
    if(this.recvSeq===null){this.recvSeq=seq;return true;}
    if(seq!==nextSeq(this.recvSeq)){if(isOld(seq,this.recvSeq))this.ack(this.recvSeq);else this.control('Nack',{seqNo:this.recvSeq});return false;}
    this.recvSeq=seq;this.ack(seq);return true;
  }
  control(name,body){try{if(!this.closed&&this.socket?.readyState===1)this.socket.send(this.pack(name,body));}catch{this.fail('控制消息发送失败');}}
  ack(seq){this.nextAck=seq;if(this.ackTimer==null)this.ackTimer=setTimeout(()=>{this.ackTimer=null;this.control('Ack',{seqNo:this.nextAck});},1000);}
  ping(){this.pingTimestamp=Date.now();this.control('PingRequest',{clientTimestamp:String(this.pingTimestamp)});}
  async redeem(code){
    if(this.closed||!this.authorized)throw new Error('游戏会话未就绪');if(this.pending)throw new Error('只允许一个待处理请求');
    const r=await new Promise((resolve,reject)=>{
      const timer=setTimeout(()=>this.fail('兑换响应超时，结果未知，未自动重试'),this.responseTimeoutMs);
      this.pending={resolve,reject,timer};
      try{this.sendSeq=nextSeq(this.sendSeq);this.socket.send(this.pack('GotGiftCodeRequest',{giftCode:code},this.sendSeq));}catch{this.fail('兑换发送失败，结果未知，未自动重试');}
    });
    if(r.name==='PromptResponse'){
      const prompt=r.body.prompt;
      if(!Object.hasOwn(PROMPTS,prompt))return {status:'unknown',detail:'未识别的服务端提示 '+prompt+'，停止并人工核对',stop:true};
      return {status:'rejected',detail:PROMPTS[prompt]+'（提示编号 '+prompt+'）',stop:prompt===101};
    }
    if(r.name!=='GotRewardResponse'||rewardCount(r.body)===0)return {status:'unknown',detail:'未确认的奖励响应；停止并在游戏/邮件核对，勿自动重试',stop:true};
    return {status:'success',detail:'服务器返回可解析奖励；请在游戏或邮件核对到账',stop:false};
  }
  fail(message){if(this.closed)return;const error=new Error(message);if(this.authReject){this.authReject(error);this.authReject=null;this.authResolve=null;}if(this.pending){clearTimeout(this.pending.timer);this.pending.reject(error);this.pending=null;}this.close();}
  close(){if(this.closed)return;this.closed=true;clearTimeout(this.authTimer);clearTimeout(this.ackTimer);clearInterval(this.tick);try{this.socket?.close(1000,'local stop');}catch{}this.login=null;}
}
