// 无界面命令行入口：在本进程内启动服务、走同一套 API，结束即关闭。
//
//   · 不占用 8765，用系统分配的临时端口，不会和界面版抢端口。
//   · 不加载浏览器，纯命令行；适合被脚本或 Agent 调用。
//   · 默认「离线模拟」，真实兑换必须显式 --live，且必须 --yes。
//   · 预览令牌只活在本进程内存里，所以预览与执行必须同一次调用完成，
//     这也是为什么只提供 preview（只预览）和 redeem（预览+执行）两条命令。
//
// 用法：
//   node tools/redeem.mjs check
//   node tools/redeem.mjs preview --codes cdk.txt [--snapshot s.local.json] [--live] [--interval 3000]
//   node tools/redeem.mjs redeem  --codes cdk.txt --snapshot s.local.json --live --yes
import { readFile } from 'node:fs/promises';
import { setTimeout as sleep } from 'node:timers/promises';
import { createApp } from '../src/server.mjs';

function usage() {
  console.log([
    '用法:',
    '  node tools/redeem.mjs check',
    '  node tools/redeem.mjs preview --codes <文件> [--snapshot <快照>] [--live] [--interval 3000]',
    '  node tools/redeem.mjs redeem  --codes <文件> --snapshot <快照> --live --yes',
    '',
    '不加 --live 就是离线模拟：不连接游戏、不消耗任何礼包码。',
    '真实兑换不可撤回，先用 preview 让用户核对完整清单与账号，确认后再用 redeem --yes 执行。',
  ].join('\n'));
}

const argv = process.argv.slice(2);
const command = argv[0];
const opt = { codes: null, snapshot: null, interval: 3000, live: false, yes: false };
for (let i = 1; i < argv.length; i++) {
  const arg = argv[i];
  if (arg === '--codes') opt.codes = argv[++i];
  else if (arg === '--snapshot') opt.snapshot = argv[++i];
  else if (arg === '--interval') opt.interval = Number(argv[++i]);
  else if (arg === '--live') opt.live = true;
  else if (arg === '--yes') opt.yes = true;
  else if (arg === '--help' || arg === '-h') { usage(); process.exit(0); }
  else { console.error('未知参数：' + arg); usage(); process.exit(2); }
}

if (!['check', 'preview', 'redeem'].includes(command)) { usage(); process.exit(2); }
if (command !== 'check' && !opt.codes) { console.error('缺少 --codes <清单文件>'); process.exit(2); }
if (opt.live && !opt.snapshot) { console.error('真实兑换需要 --snapshot <本人登录快照>；没有快照请先跑 tools/snapshot.mjs'); process.exit(2); }

const app = await createApp();
const base = await new Promise((resolve, reject) => {
  app.server.once('error', reject);
  app.server.listen(0, '127.0.0.1', () => resolve('http://127.0.0.1:' + app.server.address().port));
});

let csrf = '';
async function api(path, body) {
  const headers = { 'content-type': 'application/json' };
  if (body !== undefined) headers['x-local-token'] = csrf;
  const res = await fetch(base + path, body === undefined ? { headers } : { method: 'POST', headers, body: JSON.stringify(body) });
  const text = await res.text();
  let value;
  try { value = JSON.parse(text); } catch { value = { raw: text }; }
  if (!res.ok) throw new Error(value.error || ('HTTP ' + res.status));
  return value;
}

async function preparePlan() {
  if (opt.live) {
    const login = JSON.parse((await readFile(opt.snapshot, 'utf8')).replace(/^\uFEFF/, ''));
    await api('/api/credentials', { login });
  }
  const codes = (await readFile(opt.codes, 'utf8')).replace(/^\uFEFF/, '');
  const plan = await api('/api/preview', { mode: opt.live ? 'live' : 'simulation', codes, intervalMs: opt.interval });
  console.log('模式：' + (plan.mode === 'live' ? '真实兑换（不可撤回）' : '离线模拟（不连接游戏）'));
  if (plan.maskedAccount) console.log('账号：' + plan.maskedAccount);
  console.log('待提交：' + plan.codes.length + ' 个    防重拦截：' + plan.blocked.length + ' 个    已过期：' + plan.expired.length + ' 个    重复：' + plan.duplicates.length + ' 个');
  console.log('');
  for (const row of plan.codes) console.log('  ' + row.code);
  if (plan.blocked.length) {
    console.log('');
    console.log('以下曾被提交过，已自动跳过：');
    for (const row of plan.blocked) console.log('  ' + row.code);
  }
  console.log('');
  return plan;
}

async function execute(plan) {
  const started = await api('/api/start', {
    mode: opt.live ? 'live' : 'simulation',
    codes: (await readFile(opt.codes, 'utf8')).replace(/^\uFEFF/, ''),
    intervalMs: opt.interval,
    previewToken: plan.previewToken,
    confirmation: true,
  });
  console.log('已开始：' + started.runId);
  let last = '';
  for (;;) {
    await sleep(2000);
    const status = await api('/api/status');
    if (status.state !== last) {
      last = status.state;
      console.log('[状态] ' + status.state + (status.error ? ' | ' + status.error : ''));
    }
    if (!['running', 'stopping'].includes(status.state)) {
      const tally = {};
      for (const row of status.rows) tally[row.status] = (tally[row.status] || 0) + 1;
      console.log('汇总：' + JSON.stringify(tally));
      const abnormal = status.rows.filter(row => row.status !== 'success' && row.status !== 'simulated');
      if (abnormal.length) {
        console.log('异常明细：');
        for (const row of abnormal) console.log('  ' + row.code + ' | ' + row.status + ' | ' + row.detail);
      }
      return status;
    }
  }
}

try {
  const boot = await api('/api/bootstrap');
  csrf = boot.csrf;

  if (command === 'check') {
    const major = Number(process.versions.node.split('.')[0]);
    console.log('Node：' + process.version + (major >= 22 ? '' : '（需要 22.15 及以上）'));
    const found = await api('/api/processes');
    const list = Array.isArray(found.processes) ? found.processes : [];
    console.log('微信小程序进程：' + list.length + ' 个 WeChatAppEx');
    for (const item of list.slice(0, 8)) console.log('  PID ' + item.pid + '  ' + item.memoryMB + ' MB');
    if (!list.length) console.log('  未发现。请先打开微信并进入「疯狂水世界」主界面。');
    console.log('本地兑换日记：' + app.journal.rows.length + ' 条');
  } else if (command === 'preview') {
    const plan = await preparePlan();
    console.log('预览令牌 ' + plan.previewToken + ' 仅在本进程内有效；核对无误后用 redeem 执行。');
  } else {
    if (!opt.live) { console.error('redeem 需要显式 --live。只做预览请用 preview。'); process.exit(2); }
    if (!opt.yes) { console.error('真实兑换不可撤回：请先用 preview 核对完整清单与账号，确认后加 --yes 再执行。'); process.exit(2); }
    const plan = await preparePlan();
    if (!plan.codes.length) { console.error('没有可提交的兑换码，已停止，未连接游戏。'); process.exitCode = 1; }
    else await execute(plan);
  }
} catch (error) {
  console.error('失败：' + error.message);
  process.exitCode = 1;
} finally {
  await app.close();
}
