// 有效期监视：按递增的快照年龄自动做登录探针，把结果追加到 CSV，直到第一次失败。
//
//   · 只用 LoginRequest + LoginResponse，不发兑换请求、不消耗任何码。
//   · 每次「探测成功」都会把当前游戏客户端顶下线；失败后不再探测，也就不会再顶。
//   · 判定依据是签名里的 timestamp，年龄 = 现在 − 签发时刻。
//
// 用法：
//   node tools/ttl-watch.mjs data/s1.local.json                默认目标年龄序列
//   node tools/ttl-watch.mjs data/s1.local.json --once         立刻探一次就退出
//   node tools/ttl-watch.mjs data/s1.local.json --targets 600,1800,3600
import { readFile, appendFile, writeFile, mkdir, stat } from 'node:fs/promises';
import { setTimeout as sleep } from 'node:timers/promises';
import { join, dirname, resolve, basename } from 'node:path';
import { GameSession } from '../src/session.mjs';
import { validateLogin } from '../src/credentials.mjs';

// 目标年龄（秒）：前段密、后段疏，覆盖 8 分钟到 24 小时
const DEFAULT_TARGETS = [480, 720, 960, 1200, 1500, 1800, 2400, 3000, 3600, 4500, 5400, 7200, 10800, 14400, 21600, 28800, 43200, 86400];

const argv = process.argv.slice(2);
const file = argv[0];
if (!file) {
  console.error('用法: node tools/ttl-watch.mjs <快照文件> [--once] [--targets 600,1800,...]');
  process.exit(2);
}
let once = false, targets = DEFAULT_TARGETS;
for (let i = 1; i < argv.length; i++) {
  if (argv[i] === '--once') once = true;
  else if (argv[i] === '--targets') {
    targets = argv[++i].split(',').map(Number).filter(n => Number.isFinite(n) && n > 0).sort((a, b) => a - b);
  } else { console.error('未知参数：' + argv[i]); process.exit(2); }
}

let checked;
try {
  checked = validateLogin(JSON.parse((await readFile(file, 'utf8')).replace(/^\uFEFF/, '')));
} catch (error) {
  console.error('快照不可用：' + error.message);
  process.exit(2);
}

const { login, maskedAccount } = checked;
const t0 = Number(login.eworldParams.timestamp);
const tail = String(login.eworldParams.openId).slice(-6);
const csv = join(dirname(resolve(file)), 'ttl-' + tail + '.csv');

async function probe() {
  const session = new GameSession(login, { responseTimeoutMs: 20000 });
  const started = Date.now();
  let ok = false, reason = '';
  try { await session.open(); ok = true; }
  catch (error) { reason = error.message; }
  finally { session.close(); }
  return { ok, reason, ms: Date.now() - started };
}

await mkdir(dirname(csv), { recursive: true });
try { await stat(csv); }
catch { await writeFile(csv, 'iso_time,age_seconds,result,handshake_ms,reason\n', 'utf8'); }

async function record(age, r) {
  const line = [new Date().toISOString(), age, r.ok ? 'OK' : 'FAIL', r.ms, (r.reason || '').replace(/[\r\n,]/g, ' ')].join(',') + '\n';
  await appendFile(csv, line, 'utf8');
  console.log((r.ok ? '可用  ' : '失效  ') + '年龄 ' + age + ' 秒  ' + r.ms + ' ms' + (r.reason ? '  ' + r.reason : ''));
}

console.log('监视快照：' + basename(file) + '  账号 ' + maskedAccount);
console.log('签发时刻：' + new Date(t0).toISOString() + '  当前年龄 ' + Math.round((Date.now() - t0) / 1000) + ' 秒');
console.log('结果写入：' + csv);

if (once) {
  const age = Math.round((Date.now() - t0) / 1000);
  const r = await probe();
  await record(age, r);
  process.exit(r.ok ? 0 : 1);
}

for (const target of targets) {
  const wait = t0 + target * 1000 - Date.now();
  if (wait < -60_000) continue;            // 已经明显越过这个目标，跳过而不是连发
  if (wait > 0) await sleep(wait);
  const age = Math.round((Date.now() - t0) / 1000);
  const r = await probe();
  await record(age, r);
  if (!r.ok) {
    console.log('');
    console.log('已找到上界：签发后 ' + age + ' 秒失效。');
    process.exit(0);
  }
}
console.log('');
console.log('本次监视结束，仍未失效；继续加大 --targets 再跑。');
