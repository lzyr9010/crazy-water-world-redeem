// 采集登录快照：只读扫描微信小程序进程内存里的 LoginRequest 帧，
// 校验后把 eworldParams / eworldClientInfo 保存成可复用的登录快照。
//
// 快照含 token / sign / openId，属本机隐私资料：
//   - 默认落在 data/ 下，已被 .gitignore 与 打包.ps1 双重排除；
//   - 文件名以 .local.json 结尾，同样被排除；
//   - 不要把快照粘贴到聊天、截图或版本库。
//
// 用法：
//   node tools/snapshot.mjs                 自动扫描（推荐）
//   node tools/snapshot.mjs --pid 18280     只读指定进程
//   node tools/snapshot.mjs --pick 2        命中多个候选时选第 2 个
//   node tools/snapshot.mjs --out path.json 指定输出路径
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { writeFile, mkdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { decodeFrame, decodeMessage } from '../src/codec.mjs';
import { schemas } from '../src/schema.mjs';
import { normalizeCandidate, validateLogin } from '../src/credentials.mjs';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const execute = promisify(execFile);
const opt = { auto: true, pid: null, out: null, pick: null };

function usage() {
  console.log([
    '用法: node tools/snapshot.mjs [--auto | --pid N] [--pick N] [--out 文件]',
    '',
    '  前置条件：微信里打开「疯狂水世界」并已进入主界面（登录帧才会留在内存）。',
    '  不带参数等价于 --auto（按内存降序扫描最多 16 个 WeChatAppEx 进程）。',
  ].join('\n'));
}

for (let i = 0; i < process.argv.length - 2; i++) {
  const arg = process.argv[i + 2];
  if (arg === '--auto') { opt.auto = true; opt.pid = null; }
  else if (arg === '--pid') { opt.auto = false; opt.pid = Number(process.argv[++i + 2]); }
  else if (arg === '--out') { opt.out = process.argv[++i + 2]; }
  else if (arg === '--pick') { opt.pick = Number(process.argv[++i + 2]); }
  else if (arg === '--help' || arg === '-h') { usage(); process.exit(0); }
  else { console.error('未知参数：' + arg); usage(); process.exit(2); }
}

if (opt.pid != null && (!Number.isSafeInteger(opt.pid) || opt.pid <= 0)) {
  console.error('--pid 需要一个正整数的进程号'); process.exit(2);
}

async function runCapture() {
  if (process.platform !== 'win32') throw new Error('自动采集仅支持 Windows；其他系统请手动提供本人登录 JSON。');
  const ps = join(process.env.SystemRoot ?? 'C:/Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
  const args = ['-NoProfile', '-ExecutionPolicy', 'RemoteSigned', '-File', join(ROOT, 'tools', 'CaptureLogin.ps1')];
  if (opt.auto) args.push('-Auto'); else args.push('-TargetPid', String(opt.pid));
  const { stdout } = await execute(ps, args, { encoding: 'utf8', timeout: 180000, maxBuffer: 4 * 1024 * 1024, windowsHide: true });
  return JSON.parse(stdout.replace(/^\uFEFF/, ''));
}

let scanned;
try {
  scanned = await runCapture();
} catch (error) {
  console.error('采集脚本运行失败：' + (error.code === 'ETIMEDOUT' ? '超时' : 'PowerShell 返回异常'));
  console.error('请确认微信与本工具权限相同（都不是管理员身份），且未修改执行策略。');
  process.exit(1);
}

// PowerShell 单元素数组会退化成对象，这里统一成数组。
const list = Array.isArray(scanned?.scanned) ? scanned.scanned : scanned?.scanned ? [scanned.scanned] : [];
if (!list.length) {
  console.error('没有扫描到任何 WeChatAppEx 进程。请先在微信里打开「疯狂水世界」小游戏。');
  process.exit(1);
}

const found = new Map();
let frames = 0, unusable = 0;
for (const proc of list) {
  for (const base64 of (proc.frames ?? []).slice(0, 32)) {
    frames++;
    let candidate = null;
    try {
      const frame = decodeFrame(Buffer.from(String(base64), 'base64'));
      if (frame.name !== 'LoginRequest') continue;
      candidate = normalizeCandidate(decodeMessage(schemas.LoginRequest, frame.body, schemas));
    } catch { unusable++; continue; }
    if (!candidate) { unusable++; continue; }
    let checked;
    try { checked = validateLogin(candidate); } catch { unusable++; continue; }
    const key = createHash('sha256').update(JSON.stringify(checked.login)).digest('hex');
    if (!found.has(key)) found.set(key, { ...checked, pid: proc.pid });
  }
}

const candidates = [...found.values()];
const scannedMB = list.reduce((sum, proc) => sum + (Number(proc.scannedMB) || 0), 0);
console.log('扫描 ' + list.length + ' 个进程 / 约 ' + scannedMB + ' MB，命中登录帧 ' + frames + ' 个，可用候选 ' + candidates.length + ' 个。');

if (!candidates.length) {
  console.error(unusable
    ? '找到帧但无法校验（可能缺少 eworldClientInfo）。请重新进入游戏主界面后再试。'
    : '内存里没有登录帧。请确认小游戏已打开并进入过主界面；刚启动时帧可能还没写入，等几秒重试。');
  process.exit(1);
}

let index = 0;
if (candidates.length > 1) {
  if (opt.pick == null) {
    candidates.forEach((c, i) => console.log('  [' + (i + 1) + '] ' + c.maskedAccount + '  来自 PID ' + c.pid));
    console.error('命中多个候选。确认哪个是本人账号后，用 --pick N 指定。');
    process.exit(2);
  }
  index = opt.pick - 1;
  if (!Number.isInteger(index) || index < 0 || index >= candidates.length) {
    console.error('--pick 超出范围（1~' + candidates.length + '）'); process.exit(2);
  }
}

const chosen = candidates[index];
const tail = String(chosen.login.eworldParams.openId).slice(-6);
const outPath = opt.out ? resolve(opt.out) : join(ROOT, 'data', 'snapshot-' + tail + '.local.json');
await mkdir(dirname(outPath), { recursive: true });
await writeFile(outPath, JSON.stringify(chosen.login, null, 2) + '\n', 'utf8');

console.log('');
console.log('已保存快照：' + outPath);
console.log('账号：' + chosen.maskedAccount + '（来自 PID ' + chosen.pid + '）');
console.log('采集时间：' + new Date().toISOString());
for (const warning of chosen.warnings) console.log('注意：' + warning);
console.log('');
console.log('这个文件含真实 token / sign。不要提交、不要打包、不要发给别人。');
