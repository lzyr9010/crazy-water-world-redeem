﻿param([switch]$List, [switch]$Auto, [int[]]$TargetPid = @())
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)

if ($List) {
  $items = @(Get-Process | Where-Object ProcessName -eq 'WeChatAppEx' | Sort-Object WorkingSet64 -Descending | ForEach-Object { @{pid=$_.Id; memoryMB=[int]($_.WorkingSet64/1MB)} })
  ConvertTo-Json -InputObject @{processes=$items} -Compress -Depth 5
  exit 0
}

$targets = @()
if ($Auto) {
  $targets = @(Get-Process | Where-Object ProcessName -eq 'WeChatAppEx' | Sort-Object WorkingSet64 -Descending | Select-Object -First 16)
} else {
  foreach ($id in $TargetPid) {
    $p = Get-Process -Id $id
    if ($p.ProcessName -ne 'WeChatAppEx') { throw '只允许读取本人选定的 WeChatAppEx 进程' }
    $targets += $p
  }
}
if ($targets.Count -eq 0) { throw '没有可扫描的 WeChatAppEx 进程' }

Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;

public static class GiftLoginFrameReader {
  [StructLayout(LayoutKind.Sequential)] struct MBI { public IntPtr BaseAddress; public IntPtr AllocationBase; public uint AllocationProtect; public UIntPtr RegionSize; public uint State; public uint Protect; public uint Type; }
  [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr OpenProcess(uint access,bool inherit,int pid);
  [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);
  [DllImport("kernel32.dll",SetLastError=true)] static extern UIntPtr VirtualQueryEx(IntPtr h,IntPtr address,out MBI mbi,UIntPtr length);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool ReadProcessMemory(IntPtr h,IntPtr address,byte[] bytes,UIntPtr size,out UIntPtr read);

  const int CHUNK = 1024 * 1024;
  const int OVERLAP = 512;
  static readonly byte[] NEEDLE = Encoding.ASCII.GetBytes("LoginRequest");
  static readonly byte[] NAME = Encoding.ASCII.GetBytes("LoginRequest");

  public static string[] Scan(int pid, int maxMs, long maxBytes, out long scanned) {
    scanned = 0;
    var frames = new List<string>();
    IntPtr h = OpenProcess(0x0410, false, pid);
    if (h == IntPtr.Zero) throw new Exception("无法只读打开进程，请以与微信相同权限启动");
    var watch = Stopwatch.StartNew();
    long address = 0;
    try {
      while (address < 0x7fffffffffff && watch.ElapsedMilliseconds < maxMs && scanned < maxBytes) {
        MBI info;
        if (VirtualQueryEx(h, new IntPtr(address), out info, new UIntPtr((uint)Marshal.SizeOf(typeof(MBI)))) == UIntPtr.Zero) break;
        long size = (long)info.RegionSize.ToUInt64();
        long baseAddr = info.BaseAddress.ToInt64();
        if (size <= 0 || baseAddr + size <= address) break;
        address = baseAddr + size;
        if (info.State != 0x1000 || (info.Protect & 0x101) != 0 || (info.Protect & 0xee) == 0) continue;
        for (long offset = 0; offset < size && watch.ElapsedMilliseconds < maxMs && scanned < maxBytes; offset += CHUNK) {
          int count = (int)Math.Min(CHUNK, size - offset);
          byte[] raw = new byte[count];
          UIntPtr read;
          ReadProcessMemory(h, new IntPtr(baseAddr + offset), raw, new UIntPtr((uint)count), out read);
          int n = (int)read.ToUInt64();
          scanned += n;
          if (n <= 0) continue;
          // 前置 OVERLAP 字节，保证跨块边界的帧头也能定位
          int prefix = 0;
          byte[] buf;
          if (offset >= OVERLAP) {
            byte[] head = new byte[OVERLAP];
            UIntPtr readHead;
            if (ReadProcessMemory(h, new IntPtr(baseAddr + offset - OVERLAP), head, new UIntPtr((uint)OVERLAP), out readHead) && readHead.ToUInt64() == (ulong)OVERLAP) {
              prefix = OVERLAP;
              buf = new byte[prefix + n];
              Buffer.BlockCopy(head, 0, buf, 0, prefix);
              Buffer.BlockCopy(raw, 0, buf, prefix, n);
            } else { buf = raw; }
          } else { buf = raw; }
          int length = buf.Length;
          for (int i = 0; i <= length - NEEDLE.Length; i++) {
            if (buf[i] != NEEDLE[0]) continue;
            int j = 1;
            while (j < NEEDLE.Length && buf[i + j] == NEEDLE[j]) j++;
            if (j != NEEDLE.Length) continue;
            int pos = i - 10;
            if (pos < prefix) continue;                 // 帧头落在本块之前，交给上一块处理
            if (pos + 23 > length) continue;
            if (buf[pos + 4] != 2) continue;             // 版本号
            if (buf[pos + 9] != NAME.Length) continue;   // 消息名长度
            if (buf[pos + 22] != 0) continue;            // 仅接受未压缩帧
            long contentLen = ((long)buf[pos] << 24) | ((long)buf[pos + 1] << 16) | ((long)buf[pos + 2] << 8) | buf[pos + 3];
            long total = contentLen + 4;
            if (total < 23 || total > 16384) continue;
            if (pos + total > length) continue;
            byte[] frame = new byte[total];
            Buffer.BlockCopy(buf, pos, frame, 0, (int)total);
            frames.Add(Convert.ToBase64String(frame));
            if (frames.Count >= 32) return frames.ToArray();
            i += NEEDLE.Length - 1;
          }
        }
      }
    } finally { CloseHandle(h); }
    return frames.ToArray();
  }
}
'@

$result = @()
foreach ($proc in $targets) {
  $frames = @()
  $scanned = 0
  try { $frames = @([GiftLoginFrameReader]::Scan($proc.Id, 9000, 1610612736, [ref]$scanned)) }
  catch { }
  $result += @{ pid = $proc.Id; memoryMB = [int]($proc.WorkingSet64/1MB); scannedMB = [int]($scanned/1MB); frames = $frames }
}

ConvertTo-Json -InputObject @{ scanned = $result; warnings = @('只读扫描内存中的未压缩登录帧，不注入、不落盘整片内存；输出仅供本地服务在内存中解析') } -Depth 6 -Compress
