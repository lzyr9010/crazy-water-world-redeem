import {fetchSourceCodes,prepareCodes,SOURCE_URL} from '../src/source.mjs';
try {
 const records=await fetchSourceCodes(),all=prepareCodes(records,{includeExpired:true}),p=prepareCodes(records);
 console.log(JSON.stringify({sourceUrl:SOURCE_URL,checkedAt:new Date().toISOString(),sourceRecords:records.length,uniqueIncludingExpired:all.codes.length,defaultCandidates:p.codes.length,duplicateRecords:p.duplicates.length,explicitExpired:p.expired.length},null,2));
} catch {console.error('读取固定公开来源失败，未执行游戏登录或兑换；请检查网络/来源格式后再试。');process.exitCode=1;}
