// 登录探针：用一份保存好的登录快照做一次真实登录握手，只看 LoginResponse 的结果。
//
//   · 只发 LoginRequest，收到 LoginResponse 立即断开，不发 GotGiftCodeRequest，
//     因此不提交任何礼包码、不消耗任何兑换资格。
//   · 但登录本身是真实行为：成功登录可能把你正在玩的客户端踢下线。
//   · 退出码 0 = 登录成功；1 = 登录被拒或异常（原因会是 LOGIN_RESULTS 里的中文说明）。
//
// 用法：
//   node tools/probe.mjs data/snapshot-xxxxxx.local.json
import { readFile } from 'node:fs/promises';
import { GameSession } from '../src/session.mjs';
import { validateLogin } from '../src/credentials.mjs';

const file = process.argv[2];
if (!file) {
  console.error('用法: node tools/probe.mjs <快照文件>');
  process.exit(2);
}

let snapshot;
try {
  snapshot = JSON.parse((await readFile(file, 'utf8')).replace(/^\uFEFF/, ''));
} catch {
  console.error('快照读取或解析失败：' + file);
  process.exit(2);
}

let checked;
try {
  checked = validateLogin(snapshot);
} catch (error) {
  console.error('快照内容不平整，拒绝使用：' + error.message);
  process.exit(2);
}

const at = new Date();
console.log('起始时间：' + at.toISOString());
console.log('账号：' + checked.maskedAccount);

const session = new GameSession(checked.login, { responseTimeoutMs: 20000 });
const started = Date.now();
let outcome = 'FAIL', reason = '';
try {
  await session.open();
  outcome = 'OK';
} catch (error) {
  reason = error.message;
} finally {
  session.close();
}

console.log('结果：' + outcome);
if (reason) console.log('原因：' + reason);
console.log('握手耗时：' + (Date.now() - started) + ' ms');
process.exitCode = outcome === 'OK' ? 0 : 1;
