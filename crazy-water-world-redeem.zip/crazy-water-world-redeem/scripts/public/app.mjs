const $ = (id) => document.getElementById(id);
const ACTIVE_STATES = new Set(['running', 'stopping']);
const ELIGIBLE_STATUSES = new Set(['pending', 'ready', 'queued', 'valid', 'eligible', 'simulation']);
const STATUS_TEXT = {
  pending: ['待处理', '尚未发送请求。'],
  queued: ['待处理', '尚未发送请求。'],
  ready: ['可执行', '通过本地预览。'],
  sending: ['已发送', '请求已发送，等待结果；不要重复提交。'],
  running: ['处理中', '等待本次请求完成。'],
  success: ['成功', '已收到明确成功结果。'],
  simulated: ['模拟完成', '仅离线模拟，未发送游戏请求。'],
  simulation: ['离线模拟', '未发送游戏请求。'],
  failed: ['失败', '收到明确失败结果；不会自动重试。'],
  rejected: ['明确拒绝', '收到明确业务拒绝；不会自动重试。'],
  not_sent: ['未发送', '尚未发送游戏请求；不会自动恢复或重试。'],
  error: ['错误', '请求失败；请人工核查，不自动重试。'],
  unknown: ['结果未知', '可能已发出请求；请在游戏内核查，不自动重试。'],
  skipped: ['已跳过', '因历史记录或运行规则跳过，不自动重试。'],
  blocked: ['已拦截', '历史已发码或安全规则阻止；不会重复发送。'],
  expired: ['明确已过期', '来源截止日期早于上海今日日期。'],
  duplicate: ['重复项', '已按原始中文与大小写精确去重。'],
  stopped: ['已停止', '未继续发送；停止不撤回此前请求。'],
  cancelled: ['已取消', '未继续发送；停止不撤回此前请求。'],
};
const STATE_TEXT = { idle: '待开始', running: '运行中', stopping: '正在停止', completed: '已完成', stopped: '已停止', error: '运行异常' };
let csrf = '';
let connected = false;
let busy = false;
let currentAccount = '';
let previewSnapshot = null;
let snapshot = { state: 'idle', mode: 'simulation', rows: [] };
let pollTimer = null;
let polling = false;
let candidates = [];

function node(tag, text, className) {
  const element = document.createElement(tag);
  if (text !== undefined) element.textContent = String(text);
  if (className) element.className = className;
  return element;
}

function notice(message, isError = false) {
  const box = $('notice');
  box.textContent = message;
  box.classList.toggle('error', isError);
  box.hidden = !message;
}

// Never display a raw account identifier, response body, or credential field.
function maskedAccount(value) {
  if (typeof value !== 'string' || !value.trim()) return '未选择';
  const tail = value.trim().replace(/[\s*•·…]/g, '').slice(-4);
  return tail ? '账户 ····' + tail : '账户已选择';
}

function setAccount(value) {
  currentAccount = typeof value === 'string' ? value : '';
  $('account-label').textContent = maskedAccount(currentAccount);
  invalidatePreview();
}

function modeValue() {
  return document.querySelector('input[name="mode"]:checked')?.value === 'live' ? 'live' : 'simulation';
}

function active() { return ACTIVE_STATES.has(snapshot.state); }

function updateControls() {
  const locked = !connected || busy || active() || $('confirm-dialog').open;
  for (const element of document.querySelectorAll('[data-editable]')) element.disabled = locked;
  $('capture-auto').disabled = locked || !$('capture-consent').checked;
  $('capture').disabled = locked || !$('capture-consent').checked || !$('process-select').value;
  $('clear-credentials').disabled = locked || !currentAccount;
  $('stop').disabled = !connected || busy || snapshot.state !== 'running';
  $('preview').disabled = locked || !$('codes').value.trim();
  $('export-json').disabled = !snapshot.rows.length;
  $('export-csv').disabled = !snapshot.rows.length;
  for (const button of $('candidates').querySelectorAll('button')) {
    const candidate = candidates.find((item) => item.id === button.dataset.candidateId);
    button.disabled = locked || !$('capture-consent').checked || candidate?.hasClientInfo !== true;
  }
  const liveAllowed = previewSnapshot?.mode !== 'live' || (Boolean(currentAccount) && $('live-account-consent').checked && $('live-spend-consent').checked);
  $('confirm-start').disabled = !connected || busy || active() || !previewSnapshot?.codes.length || !liveAllowed;
  $('close-confirm').disabled = busy;
  $('cancel-confirm').disabled = busy;
}

function invalidatePreview() {
  previewSnapshot = null;
  $('live-account-consent').checked = false;
  $('live-spend-consent').checked = false;
  updateControls();
}

function countInput() {
  const count = $('codes').value.split(/\r\n|\n|\r/).filter((line) => line.trim().length > 0).length;
  $('input-count').textContent = count + ' 行';
  invalidatePreview();
}

async function api(path, payload, options = {}) {
  if (payload !== undefined && !csrf) throw new Error('尚未取得本地安全令牌，请刷新页面重试。');
  const controller = new AbortController();
  // Capture scans many processes and needs a longer local wait than ordinary calls.
  const limitMs = Number.isSafeInteger(options.timeoutMs) && options.timeoutMs > 0 ? options.timeoutMs : 30_000;
  const timeout = setTimeout(() => controller.abort(), limitMs);
  const headers = { Accept: 'application/json' };
  if (payload !== undefined) {
    headers['Content-Type'] = 'application/json';
    headers['x-local-token'] = csrf;
  }
  try {
    const response = await fetch(path, {
      method: payload === undefined ? 'GET' : 'POST',
      credentials: 'same-origin',
      cache: 'no-store',
      redirect: 'error',
      headers,
      body: payload === undefined ? undefined : JSON.stringify(payload),
      signal: controller.signal,
    });
    // Do not echo server error strings, which can accidentally contain secrets.
    if (!response.ok) {
      if (response.status === 403) throw new Error('本地安全校验失败，请刷新页面。');
      if (response.status === 409) throw new Error('当前状态已改变或操作被安全规则拦截，请核查进度并重新预览。');
      if (response.status === 400 || response.status === 422) throw new Error('提交内容未通过校验，请检查完整登录 JSON、兑换码和请求间隔。');
      throw new Error('本地服务无法完成操作，请检查服务状态；不会自动重试提交。');
    }
    let result;
    try { result = await response.json(); } catch { throw new Error('本地服务返回格式异常，请核查状态，不要重复提交。'); }
    if (!result || typeof result !== 'object' || Array.isArray(result)) throw new Error('本地服务返回格式异常。');
    return result;
  } catch (error) {
    if (controller.signal.aborted) throw new Error('等待本地服务超时；操作可能已接受，请核查进度，不要重复提交。');
    if (error instanceof TypeError) throw new Error('无法连接本地服务；请核查进度，不要重复提交。');
    throw error;
  } finally { clearTimeout(timeout); }
}

async function perform(work) {
  if (busy || active()) return;
  busy = true;
  updateControls();
  try { await work(); }
  catch (error) { notice(error.message || '操作失败，请核查本地服务。', true); }
  finally { busy = false; updateControls(); }
}

function warningsMessage(warnings) {
  if (!Array.isArray(warnings) || !warnings.length) return '';
  // Server warnings are locally generated status strings and never contain credential fields.
  const safe = warnings
    .filter((warning) => typeof warning === 'string' && warning.trim())
    .slice(0, 6)
    .map((warning) => warning.trim().slice(0, 200));
  return safe.length ? safe.join(' ') : '本地服务提示采集或登录数据有兼容性限制。';
}

function diagnosticsText(diagnostics) {
  if (!Array.isArray(diagnostics) || !diagnostics.length) return '';
  const total = diagnostics.reduce((sum, item) => sum + (Number(item?.scannedMB) || 0), 0);
  const frames = diagnostics.reduce((sum, item) => sum + (Number(item?.frames) || 0), 0);
  return '本次只读扫描 ' + diagnostics.length + ' 个进程、约 ' + Math.round(total) + ' MB，命中登录帧 ' + frames + ' 个。未读取磁盘缓存，也未注入进程。';
}

function candidateTime(value) {
  // This is the server capture time, never a login signature timestamp.
  const millis = typeof value === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(value) ? Date.parse(value) : NaN;
  if (!Number.isFinite(millis)) return '采集时间未提供';
  const date = new Date(millis);
  if (!Number.isFinite(date.getTime())) return '采集时间未知';
  return '采集时间 ' + new Intl.DateTimeFormat('zh-CN', { timeZone: 'Asia/Shanghai', dateStyle: 'short', timeStyle: 'short' }).format(date) + '（上海）';
}

function renderCandidates() {
  const container = $('candidates');
  container.replaceChildren();
  if (!candidates.length) {
    container.append(node('p', '未发现可用候选；请检查进程是否属于本人、微信版本兼容性，或手动提供完整登录 JSON。', 'help'));
    return;
  }
  for (const candidate of candidates) {
    const row = node('div', undefined, 'candidate');
    const info = node('div');
    info.append(node('strong', maskedAccount(candidate.maskedAccount)), node('small', candidateTime(candidate.capturedAt)));
    if (candidate.hasClientInfo !== true) info.append(node('p', '缺少客户端信息，不能用它真实兑换。'));
    if (Number.isSafeInteger(candidate.sourcePid) && candidate.sourcePid > 0) info.append(node('small', '来源进程 PID ' + candidate.sourcePid));
    const button = node('button', candidate.hasClientInfo === true ? '选用' : '不可选', 'secondary small');
    button.type = 'button';
    button.dataset.candidateId = candidate.id;
    button.disabled = candidate.hasClientInfo !== true;
    button.addEventListener('click', () => perform(async () => {
      if (candidate.hasClientInfo !== true || !$('capture-consent').checked) throw new Error('未授权或候选数据不完整，不能选择。');
      const result = await api('/api/select-credential', { id: candidate.id });
      setAccount(result.maskedAccount);
      notice('已选择本人候选凭据，页面只显示账号尾号。请先预览。');
    }));
    row.append(info, button);
    container.append(row);
  }
  updateControls();
}

$('refresh-processes').addEventListener('click', () => perform(async () => {
  const result = await api('/api/processes');
  const select = $('process-select');
  select.replaceChildren(node('option', '请选择本人微信进程'));
  select.firstElementChild.value = '';
  for (const process of Array.isArray(result.processes) ? result.processes : []) {
    if (!Number.isSafeInteger(process.pid) || process.pid <= 0) continue;
    const memory = Number(process.memoryMB);
    const text = 'PID ' + process.pid + (Number.isFinite(memory) && memory >= 0 ? ' · ' + memory.toFixed(1) + ' MB' : '');
    const option = node('option', text);
    option.value = String(process.pid);
    select.append(option);
  }
  notice(select.options.length > 1 ? '仅列出进程，尚未读取内存。请选本人 PID 并明确授权。' : '未找到可选微信进程；可改用本人完整登录 JSON。');
}));
$('capture-consent').addEventListener('change', updateControls);
$('process-select').addEventListener('change', updateControls);
async function runCapture(payload, message) {
  if (!$('capture-consent').checked) throw new Error('请先授权只读采集本人微信进程内存。');
  candidates = [];
  $('candidates').replaceChildren();
  $('capture-warning').textContent = '';
  $('capture-diagnostics').textContent = '';
  const result = await api('/api/capture', payload, { timeoutMs: 200_000 });
  candidates = (Array.isArray(result.candidates) ? result.candidates : []).filter((item) => item && typeof item.id === 'string');
  $('capture-warning').textContent = warningsMessage(result.warnings);
  $('capture-diagnostics').textContent = diagnosticsText(result.diagnostics);
  renderCandidates();
  notice(candidates.length ? message : '未找到可用候选。' + message);
}

$('capture-auto').addEventListener('click', () => perform(async () => {
  // Scans the largest WeChat applet processes; no PID selection needed.
  await runCapture({ auto: true, consent: true }, '自动扫描结束：仅可选用含完整客户端信息的本人候选，扫描耗时取决于进程数量。');
}));
$('capture').addEventListener('click', () => perform(async () => {
  const pid = Number($('process-select').value);
  if (!Number.isSafeInteger(pid) || pid <= 0) throw new Error('请先选择本人微信 PID，或改用自动扫描。');
  await runCapture({ pid, consent: true }, '只读采集已结束。仅可选用含完整客户端信息的本人候选；不保证所有微信版本兼容。');
}));

$('submit-credentials').addEventListener('click', () => perform(async () => {
  if (!$('manual-consent').checked) throw new Error('请先确认这份登录数据属于本人并授权使用。');
  let raw = $('login-json').value;
  // Clear before parsing or any await, including failed submissions.
  $('login-json').value = '';
  $('manual-section').open = false;
  let login;
  try { login = JSON.parse(raw); }
  catch { throw new Error('输入不是有效 JSON，敏感输入已清空；请粘贴完整登录对象。'); }
  finally { raw = ''; }
  if (!login || typeof login !== 'object' || Array.isArray(login)) throw new Error('登录 JSON 必须是对象，不接受数组或字符串。敏感输入已清空。');
  try {
    const result = await api('/api/credentials', { login });
    setAccount(result.maskedAccount);
    notice('本人登录数据已提交，本页输入已清空。' + warningsMessage(result.warnings));
  } finally { login = null; $('manual-consent').checked = false; }
}));

$('clear-credentials').addEventListener('click', () => perform(async () => {
  $('login-json').value = '';
  const result = await api('/api/clear-credentials', {});
  void result;
  setAccount('');
  candidates = [];
  $('candidates').replaceChildren();
  $('capture-warning').textContent = '';
  $('capture-consent').checked = false;
  $('manual-consent').checked = false;
  notice('本地凭据已清除。已发送的请求和历史记录不会因此撤回。');
}));

function appendCodes(text) {
  const existing = $('codes').value.trimEnd();
  $('codes').value = existing ? existing + '\n' + text : text;
  countInput();
}

function itemCount(value) {
  return Array.isArray(value) ? value.length : Number.isSafeInteger(value) && value >= 0 ? value : 0;
}

$('import-source').addEventListener('click', () => perform(async () => {
  const result = await api('/api/codes');
  const records = (Array.isArray(result.records) ? result.records : []).filter((record) => record && typeof record.code === 'string' && record.code.trim());
  if (!records.length) throw new Error('固定来源未返回可用兑换码，页面格式可能已变化。');
  appendCodes(records.map((record) => record.code).join('\n'));
  $('source-stats').textContent = '已导入 ' + records.length + ' 条来源记录（保留重复以便预览统计）。默认仅排除明确截止日期早于上海今天的码；元数据由本地服务持有。';
  notice('来源已追加到列表，未执行兑换。请预览去重、过期和历史拦截后的最终清单。');
}));
$('import-file').addEventListener('click', () => $('file-input').click());
$('file-input').addEventListener('change', () => perform(async () => {
  const file = $('file-input').files?.[0];
  $('file-input').value = '';
  if (!file) return;
  if (file.size > 512 * 1024) throw new Error('TXT 文件超过 512 KiB，请拆分后导入。');
  const text = await file.text();
  appendCodes(text.replace(/^\uFEFF/, ''));
  notice('TXT 已追加，每行一码；中文、内部空格和大小写保持原样。');
}));
$('codes').addEventListener('input', countInput);
$('include-expired').addEventListener('change', invalidatePreview);
$('interval').addEventListener('input', invalidatePreview);
for (const radio of document.querySelectorAll('input[name="mode"]')) radio.addEventListener('change', invalidatePreview);

function previewPayload() {
  const intervalMs = Number($('interval').value);
  if (!Number.isInteger(intervalMs) || intervalMs < 3000 || intervalMs > 60_000) throw new Error('请求间隔须为 3000～60000 毫秒的整数。');
  const mode = modeValue();
  if (mode === 'live' && !currentAccount) throw new Error('真实兑换需先选择本人完整凭据。离线模拟不需要账号。');
  if (!$('codes').value.trim()) throw new Error('请先输入或导入兑换码。');
  return { codes: $('codes').value, includeExpired: $('include-expired').checked, intervalMs, mode };
}

$('preview').addEventListener('click', () => perform(async () => {
  const payload = previewPayload();
  const result = await api('/api/preview', payload);
  if (result.mode && result.mode !== payload.mode) throw new Error('服务端模式与预览选择不一致，已阻止确认。');
  if (typeof result.previewToken !== 'string' || !result.previewToken) throw new Error('预览确认令牌缺失，已阻止开始。请更新本地服务后重新预览。');
  const finalCodes = [];
  const seen = new Set();
  for (const record of Array.isArray(result.codes) ? result.codes : []) {
    if (!record || typeof record.code !== 'string') continue;
    if (record.status && !ELIGIBLE_STATUSES.has(record.status)) continue;
    const code = record.code.trim();
    if (code && !seen.has(code)) { finalCodes.push(code); seen.add(code); }
  }
  if (!finalCodes.length) throw new Error('预览后没有可运行码。请检查过期、历史拦截和列表内容；不要重试已发码。');
  previewSnapshot = { ...payload, codes: finalCodes, previewToken: result.previewToken, maskedAccount: result.maskedAccount || currentAccount };
  $('confirm-count').textContent = finalCodes.length + ' 个';
  $('confirm-account').textContent = payload.mode === 'simulation' && !previewSnapshot.maskedAccount ? '无需账号' : maskedAccount(previewSnapshot.maskedAccount);
  $('confirm-mode').textContent = payload.mode === 'live' ? '真实兑换（实验）' : '离线模拟';
  $('confirm-stats').textContent = '重复 ' + itemCount(result.duplicates) + ' · 明确过期 ' + itemCount(result.expired) + ' · 安全/历史拦截 ' + itemCount(result.blocked) + ' · 间隔 ' + payload.intervalMs + ' ms';
  $('confirm-risk').textContent = payload.mode === 'live' ? '真实登录可能使当前游戏掉线；兑换可能消耗资格且无法撤回。已在本人账号验证过，但不能保证你的微信/游戏版本兼容。' : '这是离线模拟，不发送游戏登录或兑换网络请求，不消耗兑换资格。模拟成功不代表真实兑换可用。';
  $('confirm-codes').replaceChildren(...finalCodes.map((code) => node('li', code)));
  $('live-consents').hidden = payload.mode !== 'live';
  $('live-account-consent').checked = false;
  $('live-spend-consent').checked = false;
  $('confirm-start').textContent = payload.mode === 'live' ? '确认真实兑换（不可撤回）' : '确认开始离线模拟';
  $('confirm-dialog').showModal();
  notice('预览完成。请在确认页核对最终数量、完整码列表、账号尾号和模式。');
}));

function closeConfirmation() {
  if (busy) return;
  $('confirm-dialog').close();
  invalidatePreview();
}
$('close-confirm').addEventListener('click', closeConfirmation);
$('cancel-confirm').addEventListener('click', closeConfirmation);
$('confirm-dialog').addEventListener('cancel', (event) => { if (busy) event.preventDefault(); });
$('confirm-dialog').addEventListener('close', () => { previewSnapshot = null; updateControls(); });
$('live-account-consent').addEventListener('change', updateControls);
$('live-spend-consent').addEventListener('change', updateControls);

$('confirm-start').addEventListener('click', () => perform(async () => {
  const confirmed = previewSnapshot;
  if (!confirmed?.codes.length) throw new Error('预览已失效，请重新预览。');
  if (confirmed.mode === 'live' && (!currentAccount || !$('live-account-consent').checked || !$('live-spend-consent').checked)) throw new Error('真实兑换须额外确认本人账号与不可逆兑换风险。');
  const payload = { confirmation: true, previewToken: confirmed.previewToken, mode: confirmed.mode, codes: confirmed.codes.join('\n'), includeExpired: confirmed.includeExpired, intervalMs: confirmed.intervalMs };
  // Latch an uncertain start as active until an authoritative status is received.
  snapshot = { state: 'running', mode: confirmed.mode, maskedAccount: confirmed.maskedAccount, rows: confirmed.codes.map((code) => ({ code, status: 'pending' })) };
  renderStatus();
  try {
    await api('/api/start', payload);
    $('confirm-dialog').close();
    notice(confirmed.mode === 'live' ? '真实任务已开始。停止仅阻止后续请求，未知结果不会自动重试。' : '离线模拟已开始，不发送游戏请求。');
  } catch (error) {
    $('confirm-dialog').close();
    notice(error.message + ' 已转为核查进度，绝不自动重试开始请求。', true);
  } finally { schedulePoll(0); }
}));

function rowStatus(status) {
  return Object.hasOwn(STATUS_TEXT, status) ? status : 'unknown';
}

function renderStatus() {
  const rows = snapshot.rows;
  $('run-state').textContent = STATE_TEXT[snapshot.state] || '状态未知';
  $('run-meta').textContent = (snapshot.mode === 'live' ? '真实兑换 · ' : '离线模拟 · ') + (snapshot.maskedAccount ? maskedAccount(snapshot.maskedAccount) : '无需账号');
  const completed = rows.filter((row) => !['pending', 'queued', 'ready', 'sending', 'running'].includes(row.status)).length;
  $('progress').max = Math.max(1, rows.length);
  $('progress').value = completed;
  $('progress-label').textContent = completed + ' / ' + rows.length;
  $('progress-help').textContent = snapshot.state === 'stopping' ? '正在等待已发送请求结束。停止不能撤回已发请求；结果未知不会自动重试。' : '运行期间每秒刷新一次进度；停止不撤回已经发送的请求。sending / unknown / skipped / blocked 都不会自动重试。';
  const body = $('results');
  const fragment = document.createDocumentFragment();
  if (!rows.length) {
    const row = node('tr');
    const cell = node('td', '还没有运行记录。先整理兑换码，再预览最终列表。', 'empty');
    cell.colSpan = 4;
    row.append(cell); fragment.append(row);
  }
  rows.forEach((item, index) => {
    const status = rowStatus(item.status);
    const [label, detail] = STATUS_TEXT[status];
    const row = node('tr');
    const statusCell = node('td');
    statusCell.append(node('span', label, 'status ' + status));
    row.append(node('td', index + 1), node('td', item.code), statusCell, node('td', detail));
    fragment.append(row);
  });
  body.replaceChildren(fragment);
  if (snapshot.state === 'error' || snapshot.error) notice('本地任务报告异常。原始响应和凭据不会显示；请人工核查未知结果，不要重复发送已发码。', true);
  updateControls();
}

function schedulePoll(delay = 1000) {
  if (pollTimer !== null) clearTimeout(pollTimer);
  pollTimer = setTimeout(() => { pollTimer = null; void pollStatus(); }, delay);
}

async function pollStatus() {
  if (polling) return;
  polling = true;
  try {
    const result = await api('/api/status');
    if (!Object.hasOwn(STATE_TEXT, result.state) || !Array.isArray(result.rows)) throw new Error('进度格式异常。');
    connected = true;
    $('connection-dot').classList.remove('error');
    $('connection-dot').classList.add('online');
    $('connection-label').textContent = '本地服务已连接';
    if (typeof result.maskedAccount === 'string' && result.maskedAccount !== currentAccount) setAccount(result.maskedAccount);
    snapshot = {
      state: Object.hasOwn(STATE_TEXT, result.state) ? result.state : 'error',
      mode: result.mode === 'live' ? 'live' : 'simulation',
      maskedAccount: typeof result.maskedAccount === 'string' ? result.maskedAccount : currentAccount,
      rows: (Array.isArray(result.rows) ? result.rows : []).filter((row) => row && typeof row.code === 'string').map((row) => ({ code: row.code, status: rowStatus(row.status) })),
      error: Boolean(result.error),
    };
    renderStatus();
    if (active()) schedulePoll();
  } catch {
    connected = false;
    $('connection-dot').classList.remove('online');
    $('connection-dot').classList.add('error');
    $('connection-label').textContent = '进度待核查 · 操作已锁定';
    updateControls();
    notice('进度连接暂时中断；任务可能仍在运行。正在仅查询状态，不重试任何登录或兑换请求。', true);
    schedulePoll();
  } finally { polling = false; }
}

$('stop').addEventListener('click', async () => {
  if (busy || snapshot.state !== 'running') return;
  busy = true; updateControls();
  try {
    await api('/api/stop', {});
    snapshot.state = 'stopping'; renderStatus();
    notice('已请求停止后续操作；已发请求仍可能完成，停止不能撤回兑换。');
  } catch (error) { notice(error.message + ' 将查询状态，不自动重试停止。', true); }
  finally { busy = false; updateControls(); schedulePoll(0); }
});

function exportData() {
  return {
    exportedAt: new Date().toISOString(),
    state: snapshot.state,
    mode: snapshot.mode,
    maskedAccount: snapshot.maskedAccount ? maskedAccount(snapshot.maskedAccount) : '无需账号',
    // Simulation never contacted the game; live rows came from real requests and must be read as such.
    contactedGame: snapshot.mode === 'live',
    rows: snapshot.rows.map((row) => ({ code: row.code, status: row.status, detail: STATUS_TEXT[rowStatus(row.status)][1] })),
  };
}

function csvCell(value) {
  let text = String(value ?? '');
  // Neutralize formula prefixes, including tab/CR and whitespace before a formula.
  if (/^[=+@\-\t\r]/.test(text) || /^\s+[=+@\-\t\r]/.test(text)) text = "'" + text;
  return '"' + text.replace(/"/g, '""') + '"';
}

function download(contents, extension, contentType) {
  const blob = new Blob([contents], { type: contentType });
  const url = URL.createObjectURL(blob);
  const link = node('a');
  link.href = url;
  link.download = '疯狂水世界-' + snapshot.mode + '-' + new Date().toISOString().replace(/[:.]/g, '-') + '.' + extension;
  document.body.append(link); link.click(); link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
$('export-json').addEventListener('click', () => download(JSON.stringify(exportData(), null, 2), 'json', 'application/json;charset=utf-8'));
$('export-csv').addEventListener('click', () => {
  const data = exportData();
  const rows = [['兑换码', '状态', '说明', '模式', '账号尾号'], ...data.rows.map((row) => [row.code, row.status, row.detail, data.mode, data.maskedAccount])];
  download('\uFEFF' + rows.map((row) => row.map(csvCell).join(',')).join('\r\n'), 'csv', 'text/csv;charset=utf-8');
});

window.addEventListener('pagehide', () => {
  $('login-json').value = '';
  candidates = [];
  csrf = '';
  currentAccount = '';
  previewSnapshot = null;
  connected = false;
  $('candidates').replaceChildren();
  if ($('confirm-dialog').open) $('confirm-dialog').close();
  if (pollTimer !== null) clearTimeout(pollTimer);
  pollTimer = null;
});
window.addEventListener('pageshow', (event) => { if (event.persisted) void boot(); });

async function boot() {
  updateControls();
  try {
    const result = await api('/api/bootstrap');
    if (typeof result.csrf !== 'string' || !result.csrf) throw new Error('本地安全令牌缺失，请重启服务或刷新页面。');
    csrf = result.csrf;
    connected = true;
    $('connection-dot').classList.add('online');
    $('connection-label').textContent = '本地服务已连接';
    $('version').textContent = '实验版 ' + (typeof result.version === 'string' ? result.version.slice(0, 32) : '—') + ' · 本人账号有限验证';
    await pollStatus();
  } catch (error) {
    connected = false;
    $('connection-dot').classList.remove('online');
    $('connection-dot').classList.add('error');
    $('connection-label').textContent = '本地服务连接失败';
    notice(error.message || '连接失败，请确认本地服务已启动。', true);
  } finally { updateControls(); }
}
void boot();
